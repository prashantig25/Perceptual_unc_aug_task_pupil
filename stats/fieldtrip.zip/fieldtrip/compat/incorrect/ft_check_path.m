function st = ft_check_path
% See README
st = false;